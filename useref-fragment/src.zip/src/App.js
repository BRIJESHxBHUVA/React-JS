import './App.css';
import Refer from './Refer';

function App() {
  return (
    <div className="App">
      <Refer/>
    </div>
  );
}

export default App;
