import React from 'react'

const home = () => {
  return (
    <div>
      You are signIN
    </div>
  )
}

export default home
