import './App.css';
import GoogleAuth from './GoogleAuth';


function App() {
  return (
   <>
   
    <GoogleAuth/>

   </>
  );
}

export default App;
