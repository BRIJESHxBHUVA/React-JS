import { createContext } from "react";
const ContextValue = createContext()
export default ContextValue
