import './App.css';
import Context from './Context';
import Home from './Home';

function App() {
  return (
    <>
      <Context>
        <Home/>
      </Context>
    </>
  );
}

export default App;
