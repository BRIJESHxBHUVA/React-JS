import './App.css';
import EmployeesData from './EmployeesData';

function App() {
  return (
  <>

    <EmployeesData/>
  
  </>
  );
}

export default App;
