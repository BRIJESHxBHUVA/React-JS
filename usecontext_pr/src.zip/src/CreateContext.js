import { createContext } from "react";
const createcontext = createContext()

export default createcontext