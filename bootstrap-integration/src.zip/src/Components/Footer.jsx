import React from 'react'

export default function Footer() {
  return (
    <div>
      <footer class="py-5 bg-black">
            <div class="container px-5"><p class="m-0 text-center text-white small">Copyright &copy; Your Website 2023</p></div>
        </footer>
    </div>
  )
}
