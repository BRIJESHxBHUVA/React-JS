import React from 'react'

export default function reportWebVitals() {
  return (
    <div>
      
    </div>
  )
}
