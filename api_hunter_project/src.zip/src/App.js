import './App.css';
import Apidata from './Apidata';

function App() {
  return (
    <>

      <Apidata/>

    </>
  );
}

export default App;
